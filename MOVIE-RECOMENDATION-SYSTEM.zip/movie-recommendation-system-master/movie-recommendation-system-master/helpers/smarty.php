<?php

//require_once '/var/www/Smarty-2.6.6/libs/Smarty.class.php';
require_once './libs/Smarty-3.1.13/libs/Smarty.class.php';

