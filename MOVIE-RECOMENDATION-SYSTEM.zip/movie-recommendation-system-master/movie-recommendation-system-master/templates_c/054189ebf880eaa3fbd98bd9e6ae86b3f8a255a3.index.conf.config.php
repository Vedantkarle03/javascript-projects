<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'page_title_homepage' => 'SzPF | Početna',
    'recommendations' => 'Preporuke na temelju filmova',
    'search' => 'Traži',
    'page_title' => 'Sustav za preporuku filmova',
    'search_placeholder' => 'Pretraga po nazivu filma',
    'separator' => '|',
    'no_movie_info_in_db' => 'U našoj bazi ne postoje detaljnije informacije o filmu.',
    'search_on_google' => 'Pitaj Google :)',
    'open_anyway' => 'Svejedno otvori',
    'more' => 'Opširnije...',
    'name' => 'naziv',
    'movie_you_liked' => 'Filmovi koji Vam se sviđaju',
    'previous_page' => 'Prethodna stranica',
    'next_page' => 'Sljedeća stranica',
    'page' => 'Stranica',
  ),
); ?>