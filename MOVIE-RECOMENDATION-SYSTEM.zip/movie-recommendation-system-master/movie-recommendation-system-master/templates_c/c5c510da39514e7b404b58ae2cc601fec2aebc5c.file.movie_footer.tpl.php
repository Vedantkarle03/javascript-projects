<?php /* Smarty version Smarty-3.1.13, created on 2014-01-13 22:48:56
         compiled from ".\templates\movie_footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1911452d46d5896a4b7-97466850%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c5c510da39514e7b404b58ae2cc601fec2aebc5c' => 
    array (
      0 => '.\\templates\\movie_footer.tpl',
      1 => 1389653196,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1911452d46d5896a4b7-97466850',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_52d46d5896d6e0_64799353',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52d46d5896d6e0_64799353')) {function content_52d46d5896d6e0_64799353($_smarty_tpl) {?>
<div id="page-footer-box">
    <div id="footer-content-box">
        <div id="footer-content-box-left">
           <p style="text-align: center;">Copyright &copy; 2013 <a href="http://google.com">Josip Žemberi</a></p>
           
        </div>
        <div id="footer-lang-box">
            <p style="text-align: center;"> Jezik: <a href="http://google.com">Hrvatski | Engleski</a></p>
        </div> 
    </div>

</div>

<?php }} ?>