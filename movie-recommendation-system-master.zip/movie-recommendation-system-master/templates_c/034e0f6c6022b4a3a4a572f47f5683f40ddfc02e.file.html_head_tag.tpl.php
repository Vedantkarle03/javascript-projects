<?php /* Smarty version Smarty-3.1.13, created on 2014-01-18 09:39:40
         compiled from ".\templates\html_head_tag.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2036852d969db56ec99-54770307%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '034e0f6c6022b4a3a4a572f47f5683f40ddfc02e' => 
    array (
      0 => '.\\templates\\html_head_tag.tpl',
      1 => 1390037946,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2036852d969db56ec99-54770307',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_52d969db589877_03001516',
  'variables' => 
  array (
    'page_title' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52d969db589877_03001516')) {function content_52d969db589877_03001516($_smarty_tpl) {?><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>


<title> <?php echo $_smarty_tpl->getConfigVariable('page_title_homepage');?>
 <?php echo $_smarty_tpl->tpl_vars['page_title']->value;?>
</title>


<link rel='stylesheet' type='text/css' href='css/style.css'/>
<link rel="shortcut icon" href="css/img/favicon.ico" />
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/jquery.autocomplete.min.js"></script>
<script type="text/javascript" src="js/movies-autocomplete.js"></script>
<meta name='viewport' content='width=device-width, initial-scale=1.0'><?php }} ?>