<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'page_title_homepage' => 'SzPF | ',
    'search' => 'Traži',
    'page_title' => 'Sustav za preporuku filmova',
    'search_placeholder' => 'Pretraga po nazivu filma',
    'separator' => '|',
  ),
); ?>